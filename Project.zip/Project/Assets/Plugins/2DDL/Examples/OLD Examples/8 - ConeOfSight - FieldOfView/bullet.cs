﻿using UnityEngine;
using System.Collections;

public class bullet : MonoBehaviour {

	public bool isAlive = false ;
	public float rotation;


	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
